These directories contain the source of the IBSYS operating system and
several subsystems. The files were gleaned from the IBSYS tapes from
Paul Pierce's web site (www.piercefuller.com/oldibm-shadow/709x.html).

The subdirectories are:

   9PAC		- Report generator and data file maintenance
   CT		- Commercial Translator
   EDITOR	- System Editor
   FORTRAN	- FORTRAN II
   IBCBC	- COBOL
   IBFTC	- FORTRAN IV
   IBJOB	- IBJOB monitor
   IBMAP	- MAP assembler
   IBSYS	- IBSYS nucleus
   IOCS		- IOCS (I/O Control System)
   misc		- Things that go someplace
   RESTART	- RESTART 
   SORT		- SORT/MERGE 
   UTILS	- DISK Utilities

