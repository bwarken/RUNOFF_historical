
void posop();

